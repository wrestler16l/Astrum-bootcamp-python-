def my_string_index(param_1,param_2):

   n=param_1.find(param_2)
   return n
        