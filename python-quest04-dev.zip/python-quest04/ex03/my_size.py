def my_size(param_1):
    return (len(param_1))