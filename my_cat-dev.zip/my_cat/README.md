# Welcome to My Cat
***

## Task
The problem was with the my_cat function given in the assignment. I learned C language a lot through this assignment.
## Description
I solved this problem with C libraries, for loops, if statements
## Installation
You don't need to install npm to install this program, just download it
## Usage
Runs through an IDE
```
just run through the C IDE or terminal
./my_cat.c 
content_file1
 content_file2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
