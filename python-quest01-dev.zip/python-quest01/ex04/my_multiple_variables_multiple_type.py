my_age = 34;
my_name = "Luke";
my_comma = ',';

print("Hello " + my_name + my_comma + " I'm "+ str(my_age) + " years old.")