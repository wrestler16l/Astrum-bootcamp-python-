#person_age  is integer variable 
person_age = 34
print(person_age)