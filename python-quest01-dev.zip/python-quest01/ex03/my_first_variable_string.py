my_string= "Learning is growing"
print(my_string)