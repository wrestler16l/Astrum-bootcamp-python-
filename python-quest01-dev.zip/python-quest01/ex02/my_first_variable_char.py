my_letter = 'c'
print(my_letter)