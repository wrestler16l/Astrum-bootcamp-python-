def my_levenshtein(param_1,param_2):
    work_1 = []
    work_2 = []
    param  = 0
    param0 = 0

    for a in param_1:
        work_1.append(a)
    for b in param_2:
        work_2.append(b)
    
    if len(param_1) != len(param_2):
        return -1
    
    while len(work_1) > param:
        if work_1[param] != work_2[param]:
            param0 += 1
        param += 1
    return param0