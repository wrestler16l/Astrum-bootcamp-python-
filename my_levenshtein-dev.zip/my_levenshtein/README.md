# Welcome to My Levenshtein
***

## Task
proble this is string diffrence and lenght 

## Description
I solved this problem with python libraries, for loops, if statements, functions

## Installation
You don't need to install npm to install this program, just download it

## Usage
Runs through an IDE
just run through the python IDE or terminal
```
./my_levenshtein.py
Levenshtein
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
