def my_abs(param_1):
    if param_1 >= 0:
        return param_1
    else:
        return abs(param_1)