def my_is_negative(nbr):
  if nbr >= 0 :
    return 1
  else:
    return 0

# print(my_is_negative(-1))
# print(my_is_negative(1))
# print(my_is_negative(0))

#  print(my_is_negative(1337))

# REMEMBER WHEN YOU ARE FINISHED TO COMMENT ALL CALL TO YOUR
# FUNCTION my_is_negative function
# OTHERWISE IT WILL FAIL THE AUTOMATIC TEST SYSTEM
#
# <- yes this a way to comment your code
