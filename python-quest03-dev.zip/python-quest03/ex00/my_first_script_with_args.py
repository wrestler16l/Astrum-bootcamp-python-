import sys
lst = sys.argv

# i=['blah1','blah2','blah3']
for n in  range(1,len(lst)):
    print(lst[n])
