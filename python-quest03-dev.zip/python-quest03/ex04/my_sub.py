def my_sub(nbr1, nbr2):
    value = nbr1 - nbr2
    return value


