def my_is_sort(param_1):
    osish=True
    kamayish=True
    for i in range(1,len(param_1)):
        if param_1[i-1] <  param_1[i]:
          osish=False
          break
    for i in range (1,len(param_1)):
        if param_1[i-1] >param_1[i]:
            kamayish=False
            break
    if osish or kamayish:
        return True
    else:
        return False



         
        
 