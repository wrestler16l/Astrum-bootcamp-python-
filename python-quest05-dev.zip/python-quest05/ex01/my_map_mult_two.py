def my_map_mult_two(my_list):

  my_new_list = [i * 2 for i in my_list]
  return my_new_list
