param_1=["blah1","blah2","blah3"]
def my_each(param_1):
    for i in param_1:
        print(i)


  