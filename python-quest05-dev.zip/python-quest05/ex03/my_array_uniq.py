def my_array_uniq(array):
    for i in array:
        if array.count(i) > 1:
            array.remove(i)
    return sorted(array)

