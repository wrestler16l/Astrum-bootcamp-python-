def my_count_on_it(words):
    return ([len(f) for f in words])
