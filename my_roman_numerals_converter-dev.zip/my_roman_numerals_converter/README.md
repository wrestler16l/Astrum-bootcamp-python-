# Welcome to My Roman Numerals Converter
***

## Task
problem is roman numeral convert ordinary numeral
## Description
I have solved this problem by while loop and if statements , list 
## Installation
You don't need to install npm to install this program, just download it
## Usage
Runs through an IDE Python  or terminals 
```
just run through the Python IDE or terminal
./my_roman_numerals_converter.py 
my_roman_numerals_converter
```

### The Core Team

<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>