a = 10
b = 9
c = 11
d = 10
y = 9
z = 11

if a>b and b<c and a==d:
  print("a is bigger than b AND smaller than c AND equal to d")
if z>a or y>a :
  print("z OR y are bigger than a")