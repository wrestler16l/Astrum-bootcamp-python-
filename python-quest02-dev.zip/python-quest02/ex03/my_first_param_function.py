timer=10
def myfun(timer):
    print("detonation in... "+str(timer)+" secondes.")

while timer>0:
       myfun(timer)
       if timer==0:
           break
       timer-=1