index = 0

while index<100:
  print("I want to code")
  index+=1