# function my_get_seven() will return 7
def my_get_seven():
    return 7

print(my_get_seven())