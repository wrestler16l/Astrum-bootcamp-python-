def my_csv_parser(cvs_content, separator):
    result=[]
    for line in cvs_content.split("\n"):
        row =line.split(separator) 
        if len(row)>1:
            result.append(row)
    return result



     